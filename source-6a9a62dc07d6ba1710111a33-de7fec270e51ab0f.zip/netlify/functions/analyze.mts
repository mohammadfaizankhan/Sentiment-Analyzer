import type { Config } from "@netlify/functions";
import { readSession } from "./_shared/session.ts";

type Label = "Positive" | "Negative" | "Neutral";

const positive: Record<string, number> = {
  amazing: 2.2, awesome: 2.2, best: 2, excellent: 2.4, fantastic: 2.4,
  good: 1.2, great: 1.8, happy: 1.6, helpful: 1.4, impressed: 1.9,
  love: 2, perfect: 2.3, pleased: 1.7, recommend: 1.5, resolved: 1.8,
  satisfied: 1.8, smooth: 1.2, thanks: 1.2, thank: 1.2, wonderful: 2.2,
  appreciate: 1.5, fixed: 1.5, clear: 0.9, easy: 1.1, yes: 0.3,
};
const negative: Record<string, number> = {
  angry: 2.2, awful: 2.3, bad: 1.4, broken: 1.7, cancel: 1.8,
  complaint: 1.5, disappointed: 1.8, failed: 1.8, frustrating: 2,
  frustrated: 2, hate: 2.3, horrible: 2.4, issue: 0.8, late: 0.8,
  never: 0.8, problem: 1, refund: 0.7, ridiculous: 2.1, terrible: 2.4,
  unacceptable: 2.3, unresolved: 2, upset: 1.8, useless: 2.1, waiting: 0.7,
  wrong: 1.2, charged: 0.7, error: 1, concern: 0.7, worried: 1.3,
};
const negators = new Set(["not", "no", "never", "hardly", "isnt", "wasnt", "dont", "didnt", "cant", "cannot"]);
const boosters: Record<string, number> = { very: 1.45, really: 1.35, extremely: 1.7, absolutely: 1.65, quite: 1.2, slightly: 0.65 };

const emotionLexicon: Record<string, string[]> = {
  Joy: ["happy", "great", "wonderful", "love", "fantastic", "awesome", "pleased"],
  Satisfaction: ["resolved", "fixed", "satisfied", "helpful", "perfect", "thanks", "appreciate"],
  Anger: ["angry", "ridiculous", "unacceptable", "hate", "terrible"],
  Frustration: ["frustrated", "frustrating", "again", "waiting", "still", "useless"],
  Sadness: ["sad", "disappointed", "unhappy", "regret"],
  Fear: ["afraid", "worried", "concern", "risk", "scared"],
  Surprise: ["surprised", "unexpected", "wow", "suddenly"],
};

const stopwords = new Set(["about", "after", "again", "also", "been", "being", "could", "from", "have", "into", "just", "more", "that", "their", "there", "these", "they", "this", "with", "would", "your", "agent", "customer", "hello", "please", "thank"]);

function words(text: string) {
  return (text.toLowerCase().match(/[a-z']+/g) ?? []).map((word) => word.replace(/'/g, ""));
}

function analyzeSentence(text: string) {
  const tokens = words(text);
  let raw = 0;
  const evidence: string[] = [];
  for (let index = 0; index < tokens.length; index += 1) {
    const token = tokens[index];
    let value = positive[token] ?? -(negative[token] ?? 0);
    if (!value) continue;
    const prior = tokens.slice(Math.max(0, index - 3), index);
    const boost = prior.reduce((factor, item) => factor * (boosters[item] ?? 1), 1);
    value *= boost;
    if (prior.some((item) => negators.has(item))) value *= -0.85;
    raw += value;
    evidence.push(token);
  }
  if (/!{2,}/.test(text)) raw *= 1.18;
  if (/\b(but|however|although)\b/i.test(text)) raw *= 1.08;
  const score = Math.max(-1, Math.min(1, raw / Math.max(2.4, Math.sqrt(tokens.length + 2) * 1.8)));
  const sentiment: Label = score > 0.08 ? "Positive" : score < -0.08 ? "Negative" : "Neutral";
  const emotionScores = Object.entries(emotionLexicon).map(([emotion, terms]) => ({
    emotion,
    count: terms.reduce((total, term) => total + tokens.filter((token) => token === term).length, 0),
  }));
  emotionScores.sort((a, b) => b.count - a.count);
  const emotion = emotionScores[0]?.count ? emotionScores[0].emotion : sentiment === "Positive" ? "Satisfaction" : sentiment === "Negative" ? "Frustration" : "Neutral";
  return { score: Number(score.toFixed(3)), sentiment, emotion, evidence };
}

function splitTranscript(text: string) {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const units = lines.flatMap((line) => {
    const match = line.match(/^\s*(agent|representative|support|customer|caller|client|user)\s*:\s*(.*)$/i);
    const speaker = match ? match[1] : "Unknown";
    const content = match ? match[2] : line;
    const sentences = content.match(/[^.!?]+[.!?]+|[^.!?]+$/g) ?? [content];
    return sentences.map((sentence) => ({ speaker, text: sentence.trim() })).filter((item) => item.text.length > 1);
  });
  return units.slice(0, 500);
}

function labelFor(score: number): Label {
  return score > 0.08 ? "Positive" : score < -0.08 ? "Negative" : "Neutral";
}

function topTopics(text: string) {
  const counts = new Map<string, number>();
  for (const word of words(text)) {
    if (word.length < 4 || stopwords.has(word) || positive[word] || negative[word]) continue;
    counts.set(word, (counts.get(word) ?? 0) + 1);
  }
  return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([word]) => word);
}

function risk(value: number) {
  return value >= 0.58 ? "High" : value >= 0.3 ? "Medium" : "Low";
}

const response = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { "content-type": "application/json; charset=utf-8" },
});

export default async (req: Request) => {
  try {
    if (req.method !== "POST") return response({ error: "Method not allowed" }, 405);
    if (!(await readSession(req))) return response({ error: "Please sign in before running an analysis." }, 401);
    const body = (await req.json()) as { text?: unknown; filename?: unknown };
    const text = String(body.text ?? "").trim();
    if (text.length < 20) return response({ error: "Add at least 20 characters of conversation text." }, 400);
    if (text.length > 150000) return response({ error: "The transcript is too large (maximum 150,000 characters)." }, 413);

    const parts = splitTranscript(text);
    if (!parts.length) return response({ error: "No readable sentences were found." }, 400);
    const sentences = parts.map((part, index) => ({ id: index + 1, ...part, ...analyzeSentence(part.text) }));
    const counts = { Positive: 0, Negative: 0, Neutral: 0 };
    sentences.forEach((item) => { counts[item.sentiment] += 1; });
    const avg = sentences.reduce((sum, item) => sum + item.score, 0) / sentences.length;
    const overall = labelFor(avg);
    const total = sentences.length;
    const first = sentences.slice(0, Math.max(1, Math.ceil(total / 3)));
    const last = sentences.slice(-Math.max(1, Math.ceil(total / 3)));
    const average = (items: typeof sentences) => items.reduce((sum, item) => sum + item.score, 0) / items.length;
    const trajectoryDelta = average(last) - average(first);
    const trajectory = trajectoryDelta > 0.12 ? "Improving" : trajectoryDelta < -0.12 ? "Declining" : "Stable";

    const emotionCounts: Record<string, number> = {};
    sentences.forEach((item) => { emotionCounts[item.emotion] = (emotionCounts[item.emotion] ?? 0) + 1; });
    const emotions = Object.entries(emotionCounts)
      .map(([name, count]) => ({ name, count, percentage: Math.round((count / total) * 100) }))
      .sort((a, b) => b.count - a.count);

    const agent = sentences.filter((item) => /agent|representative|support/i.test(item.speaker));
    const customer = sentences.filter((item) => /customer|caller|client|user/i.test(item.speaker));
    const negativeRatio = counts.Negative / total;
    const positiveRatio = counts.Positive / total;
    const agentText = agent.map((item) => item.text).join(" ").toLowerCase();
    const empathyHits = (agentText.match(/\b(sorry|understand|appreciate|help|apologize|apologies|glad)\b/g) ?? []).length;
    const resolvedHits = (text.toLowerCase().match(/\b(resolved|fixed|completed|refund issued|done|working now)\b/g) ?? []).length;
    const unresolvedHits = (text.toLowerCase().match(/\b(unresolved|still not|not fixed|cannot help|call back)\b/g) ?? []).length;
    const satisfaction = Math.round(Math.max(0, Math.min(100, 50 + avg * 45 + resolvedHits * 6 - unresolvedHits * 8)));
    const empathy = agent.length ? Math.round(Math.min(100, 42 + empathyHits * 14 + Math.max(0, average(agent)) * 28)) : null;
    const resolution = resolvedHits > unresolvedHits ? "Resolved" : unresolvedHits > resolvedHits ? "Unresolved" : "Unclear";
    const questions = (text.match(/\?/g) ?? []).length;
    const topics = topTopics(text);
    const wordCount = words(text).length;

    const mostNegative = [...sentences].sort((a, b) => a.score - b.score)[0];
    const mostPositive = [...sentences].sort((a, b) => b.score - a.score)[0];
    const reasonBits = [
      `${Math.round(positiveRatio * 100)}% positive and ${Math.round(negativeRatio * 100)}% negative sentences`,
      `${trajectory.toLowerCase()} tone from opening to close`,
      resolution !== "Unclear" ? `${resolution.toLowerCase()} outcome language detected` : "no explicit resolution phrase detected",
    ];

    const summary = `The conversation focuses on ${topics.length ? topics.slice(0, 3).join(", ") : "a customer-support request"}. Tone is ${overall.toLowerCase()} overall and ${trajectory.toLowerCase()} through the call. The outcome appears ${resolution.toLowerCase()}.`;

    return response({
      overall: {
        sentiment: overall,
        score: Number(avg.toFixed(3)),
        confidence: Number(Math.min(0.98, 0.62 + Math.abs(avg) * 0.28 + Math.min(total, 20) / 100).toFixed(2)),
        reasoning: reasonBits.join("; ") + ".",
      },
      breakdown: {
        positive: counts.Positive,
        negative: counts.Negative,
        neutral: counts.Neutral,
      },
      sentences,
      emotions,
      summary,
      highlights: {
        riskMoment: mostNegative?.text ?? "No negative moment detected.",
        successMoment: mostPositive?.text ?? "No positive moment detected.",
      },
      kpis: {
        satisfaction,
        resolution,
        trajectory,
        churnRisk: risk(Math.min(1, negativeRatio * 1.35 + (resolution === "Unresolved" ? 0.3 : 0))),
        escalationRisk: risk(Math.min(1, negativeRatio * 1.2 + Math.max(0, -(mostNegative?.score ?? 0)) * 0.25)),
        empathy,
        agentSentiment: agent.length ? labelFor(average(agent)) : "Not labelled",
        customerSentiment: customer.length ? labelFor(average(customer)) : "Not labelled",
        talkShare: agent.length || customer.length ? Math.round((agent.length / (agent.length + customer.length)) * 100) : null,
        questions,
        words: wordCount,
        topics,
      },
      meta: {
        filename: String(body.filename ?? "conversation.txt").slice(0, 120),
        sentenceCount: total,
        model: "Explainable hybrid lexicon NLP v1",
        analyzedAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error("analysis-error", error);
    return response({ error: "The analysis could not be completed. Please try again." }, 500);
  }
};

export const config: Config = { path: "/api/analyze" };

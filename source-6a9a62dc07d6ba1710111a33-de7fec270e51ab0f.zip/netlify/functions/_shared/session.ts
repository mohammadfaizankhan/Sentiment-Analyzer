import { createHmac, timingSafeEqual, randomBytes } from "node:crypto";
import { getStore } from "@netlify/blobs";

declare const Netlify: { env: { get(key: string): string | undefined } };

export type SessionUser = { email: string; name: string; exp: number };

let cachedSecret: string | null = null;

// Falls back to a secret generated on first use and persisted in Blobs, so the
// app works immediately after deploy without requiring a manual dashboard step.
async function secret(): Promise<string> {
  if (cachedSecret) return cachedSecret;
  const configured = Netlify.env.get("AUTH_SECRET");
  if (configured && configured.length >= 32) {
    cachedSecret = configured;
    return cachedSecret;
  }
  const store = getStore({ name: "sentiment-auth", consistency: "strong" });
  const existing = await store.get("session-secret", { type: "text" });
  if (existing) {
    cachedSecret = existing;
    return cachedSecret;
  }
  const generated = randomBytes(48).toString("base64url");
  await store.set("session-secret", generated);
  cachedSecret = generated;
  return cachedSecret;
}

async function signature(payload: string): Promise<string> {
  return createHmac("sha256", await secret()).update(payload).digest("base64url");
}

export async function createSession(email: string, name: string): Promise<string> {
  const payload = Buffer.from(
    JSON.stringify({ email, name, exp: Date.now() + 24 * 60 * 60 * 1000 }),
  ).toString("base64url");
  return `${payload}.${await signature(payload)}`;
}

export async function readSession(req: Request): Promise<SessionUser | null> {
  const cookies = req.headers.get("cookie") ?? "";
  const token = cookies
    .split(";")
    .map((item) => item.trim())
    .find((item) => item.startsWith("sa_session="))
    ?.slice("sa_session=".length);
  if (!token) return null;

  const [payload, supplied] = token.split(".");
  if (!payload || !supplied) return null;
  const expected = await signature(payload);
  const left = Buffer.from(supplied);
  const right = Buffer.from(expected);
  if (left.length !== right.length || !timingSafeEqual(left, right)) return null;

  try {
    const value = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as SessionUser;
    if (!value.email || !value.name || value.exp < Date.now()) return null;
    return value;
  } catch {
    return null;
  }
}

export const sessionCookie = (token: string) =>
  `sa_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=86400`;

export const clearSessionCookie =
  "sa_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0";

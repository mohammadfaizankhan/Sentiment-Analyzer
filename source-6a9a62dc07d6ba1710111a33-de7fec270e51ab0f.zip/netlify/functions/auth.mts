import type { Config, Context } from "@netlify/functions";
import { getDeployStore, getStore } from "@netlify/blobs";
import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import {
  clearSessionCookie,
  createSession,
  readSession,
  sessionCookie,
} from "./_shared/session.ts";

type StoredUser = { email: string; name: string; salt: string; hash: string; createdAt: string };

const json = (body: unknown, status = 200, headers: HeadersInit = {}) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", ...headers },
  });

function userStore(context: Context) {
  return context.deploy?.context === "production"
    ? getStore({ name: "sentiment-users", consistency: "strong" })
    : getDeployStore({ name: "sentiment-users" });
}

function keyFor(email: string) {
  return `users/${createHash("sha256").update(email).digest("hex")}`;
}

function hashPassword(password: string, salt: string) {
  return scryptSync(password, salt, 64).toString("hex");
}

export default async (req: Request, context: Context) => {
  try {
    if (req.method === "GET") {
      const user = await readSession(req);
      return json({ user: user ? { email: user.email, name: user.name } : null });
    }

    if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
    const body = (await req.json()) as Record<string, unknown>;
    const action = String(body.action ?? "");

    if (action === "logout") {
      return json({ ok: true }, 200, { "set-cookie": clearSessionCookie });
    }

    if (action === "delete-account") {
      const session = await readSession(req);
      if (!session) return json({ error: "Please sign in first." }, 401);
      await userStore(context).delete(keyFor(session.email));
      return json({ ok: true }, 200, { "set-cookie": clearSessionCookie });
    }

    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return json({ error: "Enter a valid email address." }, 400);
    }
    if (password.length < 8) {
      return json({ error: "Password must contain at least 8 characters." }, 400);
    }

    const store = userStore(context);
    const key = keyFor(email);
    const existing = (await store.get(key, { type: "json" })) as StoredUser | null;

    if (action === "register") {
      if (existing) return json({ error: "An account with this email already exists." }, 409);
      const name = String(body.name ?? "").trim().slice(0, 60);
      if (name.length < 2) return json({ error: "Enter your name." }, 400);
      const salt = randomBytes(16).toString("hex");
      const user: StoredUser = {
        email,
        name,
        salt,
        hash: hashPassword(password, salt),
        createdAt: new Date().toISOString(),
      };
      await store.setJSON(key, user);
      const token = await createSession(email, name);
      return json({ user: { email, name } }, 201, { "set-cookie": sessionCookie(token) });
    }

    if (action === "login") {
      if (!existing) return json({ error: "Email or password is incorrect." }, 401);
      const supplied = Buffer.from(hashPassword(password, existing.salt), "hex");
      const expected = Buffer.from(existing.hash, "hex");
      if (supplied.length !== expected.length || !timingSafeEqual(supplied, expected)) {
        return json({ error: "Email or password is incorrect." }, 401);
      }
      const token = await createSession(existing.email, existing.name);
      return json(
        { user: { email: existing.email, name: existing.name } },
        200,
        { "set-cookie": sessionCookie(token) },
      );
    }

    return json({ error: "Unsupported action." }, 400);
  } catch (error) {
    console.error("auth-error", error);
    return json({ error: "Authentication service is temporarily unavailable." }, 500);
  }
};

export const config: Config = { path: "/api/auth" };

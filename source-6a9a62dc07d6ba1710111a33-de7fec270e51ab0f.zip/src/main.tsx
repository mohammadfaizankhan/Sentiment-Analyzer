import { StrictMode, useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

type User = { name: string; email: string };
type Sentence = { id: number; speaker: string; text: string; sentiment: string; score: number; emotion: string; evidence: string[] };
type Result = {
  overall: { sentiment: string; score: number; confidence: number; reasoning: string };
  breakdown: { positive: number; negative: number; neutral: number };
  sentences: Sentence[];
  emotions: { name: string; count: number; percentage: number }[];
  summary: string;
  highlights: { riskMoment: string; successMoment: string };
  kpis: Record<string, string | number | string[] | null>;
  meta: { filename: string; sentenceCount: number; model: string; analyzedAt: string };
};

const sample = `Agent: Good morning, thank you for calling Nova Mobile. How can I help today?
Customer: I am really frustrated. I was charged twice for the same monthly plan and this is the second time I have called.
Agent: I am sorry you had to contact us again. I completely understand why that is frustrating.
Customer: I need this fixed today. The extra charge is unacceptable.
Agent: I have found the duplicate transaction. I can issue the refund now and waive next month's service fee.
Customer: Will the money return to my account today?
Agent: The refund is completed on our side and should appear within two business days. I will email the confirmation immediately.
Customer: Okay, that is helpful. Thank you for finally resolving it.
Agent: You are welcome. I am glad we could fix it, and I apologize again for the inconvenience.`;

async function api<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(path, { ...options, headers: { "content-type": "application/json", ...(options?.headers ?? {}) } });
  const body = await response.json();
  if (!response.ok) throw new Error(body.error ?? "Something went wrong.");
  return body as T;
}

function Logo() {
  return <div className="logo"><span className="logo-mark">S</span><span>SignalSense</span></div>;
}

function Auth({ onSuccess }: { onSuccess: (user: User) => void }) {
  const [mode, setMode] = useState<"login" | "register">("register");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    const data = new FormData(event.currentTarget);
    try {
      const result = await api<{ user: User }>("/api/auth", {
        method: "POST",
        body: JSON.stringify({ action: mode, name: data.get("name"), email: data.get("email"), password: data.get("password") }),
      });
      onSuccess(result.user);
    } catch (err) { setError(err instanceof Error ? err.message : "Unable to continue."); }
    finally { setBusy(false); }
  }

  return <main className="auth-shell">
    <section className="auth-story">
      <Logo />
      <div className="eyebrow"><span /> AI-powered conversation intelligence</div>
      <h1>Turn every call into a <em>clear next move.</em></h1>
      <p>Upload a transcript and see explainable sentiment, emotional signals, outcome quality, and the KPIs that matter.</p>
      <div className="feature-row">
        <div><b>Sentence-level</b><span>Understand every turn</span></div>
        <div><b>12+ call KPIs</b><span>From churn to empathy</span></div>
        <div><b>Privacy-first</b><span>Server-side processing</span></div>
      </div>
    </section>
    <section className="auth-panel">
      <div className="auth-card">
        <div className="mobile-logo"><Logo /></div>
        <p className="kicker">WELCOME TO SIGNALSENSE</p>
        <h2>{mode === "register" ? "Create your workspace" : "Welcome back"}</h2>
        <p className="muted">{mode === "register" ? "Start analyzing conversations in under a minute." : "Sign in to continue to your dashboard."}</p>
        <div className="segmented">
          <button className={mode === "register" ? "active" : ""} onClick={() => { setMode("register"); setError(""); }}>Register</button>
          <button className={mode === "login" ? "active" : ""} onClick={() => { setMode("login"); setError(""); }}>Sign in</button>
        </div>
        <form onSubmit={submit}>
          {mode === "register" && <label>Full name<input name="name" autoComplete="name" placeholder="Your name" required minLength={2} /></label>}
          <label>Email address<input name="email" type="email" autoComplete="email" placeholder="you@example.com" required /></label>
          <label>Password<input name="password" type="password" autoComplete={mode === "register" ? "new-password" : "current-password"} placeholder="At least 8 characters" required minLength={8} /></label>
          {error && <div className="error" role="alert">{error}</div>}
          <button className="primary full" disabled={busy}>{busy ? "Please wait..." : mode === "register" ? "Create account" : "Sign in"}<span>→</span></button>
        </form>
        <p className="terms">By continuing, you agree to process only transcripts you are authorized to analyze.</p>
      </div>
    </section>
  </main>;
}

function Trend({ sentences }: { sentences: Sentence[] }) {
  const points = useMemo(() => {
    const items = sentences.length === 1 ? [sentences[0], sentences[0]] : sentences;
    return items.map((item, index) => `${(index / (items.length - 1)) * 100},${50 - item.score * 38}`).join(" ");
  }, [sentences]);
  return <div className="trend"><div className="trend-label top">Positive</div><div className="zero" /><svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-label="Sentiment trend"><defs><linearGradient id="line" x1="0" x2="1"><stop stopColor="#32d6b1"/><stop offset="1" stopColor="#7c6cff"/></linearGradient></defs><polyline points={points} fill="none" stroke="url(#line)" strokeWidth="2.4" vectorEffect="non-scaling-stroke" strokeLinejoin="round" strokeLinecap="round" /></svg><div className="trend-label bottom">Negative</div></div>;
}

function Donut({ result }: { result: Result }) {
  const total = result.meta.sentenceCount;
  const pos = (result.breakdown.positive / total) * 100;
  const neu = (result.breakdown.neutral / total) * 100;
  const style = { background: `conic-gradient(#32d6b1 0 ${pos}%, #9aa7b8 ${pos}% ${pos + neu}%, #ff6b7a ${pos + neu}% 100%)` };
  return <div className="donut-wrap"><div className="donut" style={style}><div><b>{Math.round(pos)}%</b><span>positive</span></div></div><div className="legend"><span><i className="pos" />Positive <b>{result.breakdown.positive}</b></span><span><i className="neu" />Neutral <b>{result.breakdown.neutral}</b></span><span><i className="neg" />Negative <b>{result.breakdown.negative}</b></span></div></div>;
}

const kpiLabels: Record<string, { label: string; icon: string; suffix?: string }> = {
  satisfaction: { label: "Satisfaction index", icon: "◎", suffix: "/100" },
  resolution: { label: "Call outcome", icon: "✓" },
  trajectory: { label: "Tone trajectory", icon: "↗" },
  churnRisk: { label: "Churn risk", icon: "◇" },
  escalationRisk: { label: "Escalation risk", icon: "!" },
  empathy: { label: "Agent empathy", icon: "♡", suffix: "/100" },
  agentSentiment: { label: "Agent sentiment", icon: "A" },
  customerSentiment: { label: "Customer sentiment", icon: "C" },
  talkShare: { label: "Agent talk share", icon: "◒", suffix: "%" },
  questions: { label: "Questions asked", icon: "?" },
  words: { label: "Words processed", icon: "#" },
};

function Results({ result, reset }: { result: Result; reset: () => void }) {
  const [filter, setFilter] = useState("All");
  const filtered = result.sentences.filter((item) => filter === "All" || item.sentiment === filter);
  return <div className="results">
    <div className="results-head"><div><button className="text-button" onClick={reset}>← New analysis</button><p className="kicker">ANALYSIS COMPLETE</p><h1>{result.meta.filename}</h1><p>{new Date(result.meta.analyzedAt).toLocaleString()} · {result.meta.sentenceCount} sentences · {result.meta.model}</p></div><div className={`verdict ${result.overall.sentiment.toLowerCase()}`}><span>Overall sentiment</span><b>{result.overall.sentiment}</b><small>{Math.round(result.overall.confidence * 100)}% confidence</small></div></div>
    <section className="summary-card"><div><p className="kicker">EXECUTIVE SUMMARY</p><h2>{result.summary}</h2><p className="reason">Why: {result.overall.reasoning}</p></div><div className="score"><span>Sentiment score</span><b>{result.overall.score > 0 ? "+" : ""}{result.overall.score.toFixed(2)}</b><small>-1 negative · +1 positive</small></div></section>
    <div className="two-col"><section className="panel"><div className="panel-title"><div><p className="kicker">SENTIMENT MIX</p><h3>Conversation balance</h3></div></div><Donut result={result} /></section><section className="panel"><div className="panel-title"><div><p className="kicker">TONE TRAJECTORY</p><h3>How the call evolved</h3></div><span className="status-pill">{String(result.kpis.trajectory)}</span></div><Trend sentences={result.sentences} /></section></div>
    <section className="panel"><div className="panel-title"><div><p className="kicker">CALL HEALTH</p><h3>Decision-ready KPIs</h3></div><span className="soft">Derived from transcript signals</span></div><div className="kpi-grid">{Object.entries(kpiLabels).map(([key, meta]) => { const value = result.kpis[key]; return value !== null && <article className="kpi" key={key}><span className="kpi-icon">{meta.icon}</span><div><p>{meta.label}</p><b>{String(value)}{meta.suffix}</b></div></article>; })}</div><div className="topics"><span>Key topics</span>{(result.kpis.topics as string[]).map((topic) => <b key={topic}>{topic}</b>)}</div></section>
    <div className="two-col highlights"><section className="panel"><p className="kicker danger">HIGHEST-RISK MOMENT</p><blockquote>“{result.highlights.riskMoment}”</blockquote></section><section className="panel"><p className="kicker success">STRONGEST MOMENT</p><blockquote>“{result.highlights.successMoment}”</blockquote></section></div>
    <section className="panel sentence-panel"><div className="panel-title"><div><p className="kicker">SENTENCE INTELLIGENCE</p><h3>Every turn, explained</h3></div><div className="filters">{["All", "Positive", "Neutral", "Negative"].map((item) => <button className={filter === item ? "active" : ""} onClick={() => setFilter(item)} key={item}>{item}</button>)}</div></div><div className="sentence-list">{filtered.map((item) => <article key={item.id}><span className={`sentiment-dot ${item.sentiment.toLowerCase()}`} /><div><div className="sentence-meta"><b>{item.speaker}</b><span>{item.emotion}</span><span>#{item.id}</span></div><p>{item.text}</p></div><strong className={item.sentiment.toLowerCase()}>{item.score > 0 ? "+" : ""}{item.score.toFixed(2)}</strong></article>)}</div></section>
  </div>;
}

function Workspace({ user, onLogout }: { user: User; onLogout: () => void }) {
  const [text, setText] = useState("");
  const [filename, setFilename] = useState("conversation.txt");
  const [dragging, setDragging] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  async function readFile(file?: File) {
    if (!file) return;
    if (!file.name.toLowerCase().endsWith(".txt")) { setError("Please choose a .txt transcript."); return; }
    if (file.size > 150000) { setError("File must be smaller than 150 KB."); return; }
    setFilename(file.name); setText(await file.text()); setError("");
  }

  async function analyze() {
    if (text.trim().length < 20) { setError("Upload a transcript or paste at least 20 characters."); return; }
    setBusy(true); setError("");
    try { setResult(await api<Result>("/api/analyze", { method: "POST", body: JSON.stringify({ text, filename }) })); window.scrollTo({ top: 0, behavior: "smooth" }); }
    catch (err) { setError(err instanceof Error ? err.message : "Analysis failed."); }
    finally { setBusy(false); }
  }

  if (result) return <><Header user={user} onLogout={onLogout} /><main className="workspace"><Results result={result} reset={() => setResult(null)} /></main></>;
  return <><Header user={user} onLogout={onLogout} /><main className="workspace upload-page"><div className="intro"><div><p className="kicker">CONVERSATION INTELLIGENCE</p><h1>What happened in this call?</h1><p>Upload or paste a transcript. SignalSense maps the emotional journey, finds risk moments, and turns dialogue into measurable call KPIs.</p></div><div className="privacy"><span>✓</span><div><b>Private by design</b><small>Your transcript is analyzed in the server function and is not stored.</small></div></div></div>
    <div className="analyze-layout"><section className="upload-card"><div className="mode-head"><div><p className="kicker">01 · ADD TRANSCRIPT</p><h2>Conversation text</h2></div><button className="sample-button" onClick={() => { setText(sample); setFilename("billing-resolution-sample.txt"); setError(""); }}>Load sample call</button></div><div className={`dropzone ${dragging ? "dragging" : ""}`} onDragOver={(e) => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={(e) => { e.preventDefault(); setDragging(false); readFile(e.dataTransfer.files[0]); }} onClick={() => fileRef.current?.click()}><input ref={fileRef} type="file" accept=".txt,text/plain" onChange={(e) => readFile(e.target.files?.[0])} hidden /><span className="upload-icon">↥</span><b>Drop a .txt transcript here</b><p>or click to browse · maximum 150 KB</p></div><div className="or"><span>OR PASTE BELOW</span></div><textarea value={text} onChange={(e) => { setText(e.target.value); setFilename("pasted-conversation.txt"); }} placeholder={'Agent: Hello, how can I help?\nCustomer: I have a problem with...'} rows={12} /><div className="textarea-foot"><span>{text.length.toLocaleString()} characters</span><button onClick={() => { setText(""); setError(""); }}>Clear</button></div>{error && <div className="error" role="alert">{error}</div>}<button className="primary analyze" onClick={analyze} disabled={busy || text.trim().length < 20}>{busy ? <><span className="spinner" /> Mapping the conversation...</> : <>Analyze conversation <span>→</span></>}</button></section>
      <aside><div className="process-card"><p className="kicker">WHAT YOU'LL GET</p>{[["01","Sentiment map","Overall and sentence-level tone"],["02","Emotion signals","Joy, frustration, anger, fear and more"],["03","Call outcomes","Resolution, trajectory and key moments"],["04","Operational KPIs","Satisfaction, churn, escalation and empathy"]].map(([n,t,d]) => <div className="process" key={n}><span>{n}</span><div><b>{t}</b><p>{d}</p></div></div>)}</div><div className="tip"><span>✦</span><div><b>For the best signal</b><p>Keep speaker labels such as “Agent:” and “Customer:” in the transcript.</p></div></div></aside></div>
  </main></>;
}

function Header({ user, onLogout }: { user: User; onLogout: () => void }) {
  return <header><Logo /><div className="header-right"><span className="live"><i /> AI engine ready</span><div className="avatar">{user.name.slice(0, 1).toUpperCase()}</div><div className="user"><b>{user.name}</b><small>{user.email}</small></div><button className="logout" onClick={onLogout}>Sign out</button></div></header>;
}

function App() {
  const [checking, setChecking] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  useEffect(() => { api<{ user: User | null }>("/api/auth").then((value) => setUser(value.user)).catch(() => setUser(null)).finally(() => setChecking(false)); }, []);
  async function logout() { try { await api("/api/auth", { method: "POST", body: JSON.stringify({ action: "logout" }) }); } finally { setUser(null); } }
  if (checking) return <div className="boot"><Logo /><span className="spinner" /></div>;
  return user ? <Workspace user={user} onLogout={logout} /> : <Auth onSuccess={setUser} />;
}

createRoot(document.getElementById("root")!).render(<StrictMode><App /></StrictMode>);
